var express = require("express");
var app     = express();
var path    = require("path");
const nodemailer = require('nodemailer');

const bodyParser = require('body-parser');
// app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(express.static('public'));

app.get('/',function(req,res){
  res.sendFile(path.join(__dirname+'/index.html'));
});

app.post('/send',function(req,res){
  let name = req.body.name;
  let email = req.body.email;
  let message = req.body.message;
  // res.send(req.body);  

  let transporter = nodemailer.createTransport({
    // host: 'smtp.mail.com',
    // service: 'mail.com',
    // secureConnection: false,
    // secure: false,
    // port: 587,
    // auth: {
    //   user: '',
    //   pass: ''
    // }
    service: 'gmail',
    auth: {
      user: 'irakli.iakobishvili.test@gmail.com',
      pass: 'iraklitest123'
    }
  });

  let mailOptions = {
    from: 'lovestar@usa.com',
    to: 'irakli.iakobishvili@gmail.com',
    subject: `New Message From ${name}`,
    html: `<p><strong>Name:</strong> ${name}</p>
           <p><strong>Email:</strong> ${email}</p>
           <p><strong>Message:</strong> ${message}</p>`
  };

  transporter.sendMail(mailOptions, function(error, info){
    if (error) {
      console.log(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });

  res.end();
});


app.listen(3000,() =>{
  console.log("Server Started!")
});