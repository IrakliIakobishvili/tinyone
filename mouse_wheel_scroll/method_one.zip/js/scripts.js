const Tinyone = {
    i: 0,
    allowScroll: true,
    changePage: function(e) {
        e.preventDefault();
        let totalPage = 6;
        let vh = window.innerHeight;

        if (e.deltaY < 0) {
            // (Tinyone.i <= 0) ? Tinyone.i = totalPage : true;
            (Tinyone.i <= 0) ? true : Tinyone.i--;
            // Tinyone.i--;
            window.scrollTo(0,(vh*Tinyone.i));     
        }
        if (e.deltaY > 0) {
            // (Tinyone.i == totalPage-1) ? Tinyone.i = -1 : true;
            (Tinyone.i == totalPage-1) ? true :  Tinyone.i++;
            // Tinyone.i++;  
            window.scrollTo(0,(vh*Tinyone.i)); 
        }
    }
}


document.addEventListener('wheel',Tinyone.changePage);

window.onbeforeunload = function () {
    window.scrollTo(0, 0);
}

document.addEventListener('keydown',function(e){
    if(e.key == "-" || e.key == "+" || e.key == "=") {
        // Tinyone.changePage;
        window.scrollTo(0, 0);
    }
});